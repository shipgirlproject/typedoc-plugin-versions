"use strict"
export const DOC_VERSIONS = [
	'dev',
	'v0.3',
	'v0.2',
];
